﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RutasDeNodos.Nodos
{
    internal class Nodos
    {
        string Nodo;
        Nodos NodoAnterior;

        public static void MetodoBusqueda(List<List<string>> ListConexion, List<List<string>> resultado, string Nodoinicio, string NodoDestino, Nodos NodoActual)
        {
            if (NodoActual == null)
            {
                NodoActual = new Nodos(Nodoinicio, null);
            }
            if (NodoActual.Nodo == NodoDestino)
            {
                List<string> Auxiliar = new List<string>();
                Nodos temp = NodoActual;
                while (temp != null)
                {
                    Auxiliar.Add(temp.Nodo);
                    temp = temp.NodoAnterior;
                }
                Auxiliar.Reverse();
                resultado.Add(Auxiliar);
            }
            else
            {
                int pos = -1;
                for (int i = 0; i < ListConexion.Count; i++)
                {
                    if (ListConexion[i][0] == NodoActual.Nodo)
                    {
                        pos = i;
                        break;
                    }
                }

                if (pos != -1 && ListConexion[pos].Count > 1)
                {
                    for (int i = 1; i < ListConexion[pos].Count; i++)
                    {
                        Nodos nodo = new Nodos(ListConexion[pos][i], NodoActual);
                        MetodoBusqueda(ListConexion, resultado, Nodoinicio, NodoDestino, nodo);
                    }
                }
            }
        }


        public Nodos(string nodo, Nodos nodoAnterior)
        {
            this.Nodo = nodo;
            this.NodoAnterior = nodoAnterior;
        }


    }

}
