﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RutasDeNodos.Nodos
{
    internal class BloqueEjecucion
    {
        public static string RecibirDatos(string num)
        {
            int NumNodos = 0;
            try
            {
                NumNodos = int.Parse(num);
            }
            catch (FormatException)
            {
                return "Se han ingresado simbolos o letras";
            }
            List<List<string>> list = new List<List<string>>();
            for (int i = 0; i < NumNodos; i++)
            {
                Console.WriteLine("Ingrese el nombre del nodo numero: " + (i + 1));
                string nombre = Console.ReadLine();
                if (nombre != "")
                {
                    bool Duplicado = false;
                    foreach (var sublist in list)
                    {
                        if (sublist[0] == nombre)
                        {
                            Duplicado = true;
                            break;
                        }
                    }
                    if (Duplicado)
                    {
                        Console.WriteLine("El nodo " + nombre + " ya existe");
                        i--;
                    }
                    else
                        list.Add(new List<string> { nombre });

                }
                else
                {
                    Console.WriteLine("El nombre del nodo no puede estar vacio");
                    i--;
                }
            }
            for (int i = 0; i < NumNodos; i++)
            {
                Console.WriteLine("Ingrese el nombre al cual el nodo: " + list[i][0] + " tiene conexion");
                string nombre = Console.ReadLine();
                if (nombre == "")
                    continue;
                if (nombre == list[i][0])
                {
                    Console.WriteLine("El nodo no puede apuntarse a si mismo");
                    i--;
                    continue;
                }
                if (nombre != list[i][0])
                {
                    int lugar = 0;
                    foreach (var sublist in list)
                    {
                        if (sublist[0] == nombre)
                        {
                            break;
                        }
                        lugar++;
                    }
                    if (list[lugar].Contains(list[i][0]))
                        Console.WriteLine("El nodo " + nombre + " ya esta apuntando al nodo" + list[i][0]);
                    else
                        list[i].Add(nombre);
                    i--;
                }
                else
                {
                    Console.WriteLine("El nodo " + nombre + " no existe");
                    i--;
                }
            }
            string NodoInicio, NodoDestino;
            while (true)
            {
                Console.WriteLine("Ingrese el nodo de inicio");
                NodoInicio = Console.ReadLine();
                if (NodoInicio != "")
                {
                    bool Existe = false;
                    foreach (var sublist in list)
                    {
                        if (sublist[0] == NodoInicio)
                        {
                            Existe = true;
                            break;
                        }
                    }
                    if (Existe)
                        break;
                    else
                        Console.WriteLine("El nodo no existe");
                }
                Console.WriteLine("No puede estar vacio el inicio");
            }
            while (true)
            {
                Console.WriteLine("Ingrese el nodo de destino");
                NodoDestino = Console.ReadLine();
                if (NodoInicio != "")
                {
                    if (NodoDestino != NodoInicio)
                    {
                        bool Existe = false;
                        foreach (var sublist in list)
                        {
                            if (sublist[0] == NodoDestino)
                            {
                                Existe = true;
                                break;
                            }
                        }
                        if (Existe)
                            break;
                        else
                            Console.WriteLine("El nodo no existe");
                    }
                    else
                        Console.WriteLine("El nodo de destino no puede ser el de inicio");

                }
                Console.WriteLine("No puede estar vacio el destino");
            }
            List<List<string>> resultado = new List<List<string>>();
            Nodos.MetodoBusqueda(list, resultado, NodoInicio, NodoDestino, null);
            if (resultado.Count > 0)
            {
                for (int l = 0; l < resultado.Count; l++)
                {
                    Console.WriteLine($"Ruta {l + 1}:");
                    for (int j = 0; j < resultado[l].Count; j++)
                    {
                        Console.Write(resultado[l][j]);
                        if (resultado[l].Count - 1 > j)
                            Console.Write("->");
                    }
                    Console.WriteLine();
                }
            }
            else
            { return ("No se encontraron rutas desde el nodo" + NodoInicio + " al nodo " + NodoDestino); }
            return "Todo funciona correctamente";
        }
    }
}
