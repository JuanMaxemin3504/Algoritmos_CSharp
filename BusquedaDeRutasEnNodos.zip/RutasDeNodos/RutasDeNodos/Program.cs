﻿// See https://aka.ms/new-console-template for more information

using RutasDeNodos.Nodos;
for(int i = 0; i < 3; i++)
{
    Console.WriteLine("Cuantos nodos vas a ingresar?");
    string numnodos = Console.ReadLine();
    Console.WriteLine(BloqueEjecucion.RecibirDatos(numnodos));
}