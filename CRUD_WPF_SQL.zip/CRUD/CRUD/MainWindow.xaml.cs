﻿using System;
using System.Collections.ObjectModel;
using Microsoft.Data.SqlClient;
using System.Windows;

namespace CRUD
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Note> Notes;
        private SqlConnection bd;

        public MainWindow()
        {
            InitializeComponent();
            Notes = new ObservableCollection<Note>();
            LoadNotes();
            NotesListView.ItemsSource = Notes;
            bd = new SqlConnection("Encrypt=false; Integrated Security = SSPI; Persist Security Info=False;Initial Catalog = NotasDB; Data Source = DESKTOP-K187PBB\\SQLEXPRESS01");
        }

        private void LoadNotes()
        {
            Notes.Clear();
            try
            {
                bd = new SqlConnection("Encrypt=false; Integrated Security = SSPI; Persist Security Info=False;Initial Catalog = NotasDB; Data Source = DESKTOP-K187PBB\\SQLEXPRESS01");
                SqlCommand select = bd.CreateCommand();
                bd.Open();
                select.CommandText = "SELECT * FROM Notas";

                SqlDataReader reader = select.ExecuteReader();
                while (reader.Read())
                {
                    Note note = new Note
                    {
                        Id = reader.GetInt32(0),
                        Content = reader.GetString(1)
                    };
                    Notes.Add(note);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Error al cargar las notas: " + ex.Message;
            }
            finally
            {
                bd.Close();
            }
        }

        private void CreateNote(string content)
        {
            try
            {
                bd = new SqlConnection("Encrypt=false; Integrated Security = SSPI; Persist Security Info=False;Initial Catalog = NotasDB; Data Source = DESKTOP-K187PBB\\SQLEXPRESS01");
                bd.Open();
                SqlCommand insert = bd.CreateCommand();
                insert.CommandText = "INSERT INTO Notas (Content) VALUES (@Content)";
                insert.Parameters.AddWithValue("@Content", content);

                insert.ExecuteNonQuery();
                StatusLabel.Text = "Nota creada con éxito.";

                LoadNotes();
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Error al crear la nota: " + ex.Message;
            }
            finally
            {
                bd.Close();
            }
        }

        private void UpdateNote(int id, string content)
        {
            try
            {
                bd = new SqlConnection("Encrypt=false; Integrated Security = SSPI; Persist Security Info=False;Initial Catalog = NotasDB; Data Source = DESKTOP-K187PBB\\SQLEXPRESS01");
                bd.Open();
                SqlCommand update = bd.CreateCommand();
                update.CommandText = "UPDATE Notas SET Content = @Content WHERE Id = @Id";
                update.Parameters.AddWithValue("@Content", content);
                update.Parameters.AddWithValue("@Id", id);

                update.ExecuteNonQuery();
                StatusLabel.Text = "Nota actualizada con éxito.";

                // Recargar las notas
                LoadNotes();
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Error al actualizar la nota: " + ex.Message;
            }
            finally
            {
                bd.Close();
            }
        }

        private void DeleteNote(int id)
        {
            bd = new SqlConnection("Encrypt=false; Integrated Security = SSPI; Persist Security Info=False;Initial Catalog = NotasDB; Data Source = DESKTOP-K187PBB\\SQLEXPRESS01");
            try
            {

                bd.Open();
                SqlCommand delete = bd.CreateCommand();
                delete.CommandText = "DELETE FROM Notas WHERE Id = @Id";
                delete.Parameters.AddWithValue("@Id", id);

                delete.ExecuteNonQuery();
                StatusLabel.Text = "Nota eliminada con éxito.";

                LoadNotes();
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "Error al eliminar la nota: " + ex.Message;
            }
            finally
            {
                bd.Close();
            }
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            string content = NoteTextBox.Text;
            if (!string.IsNullOrEmpty(content))
            {
                CreateNote(content);
                NoteTextBox.Clear();
            }
            else
            {
                StatusLabel.Text = "No se puede crear una nota vacía.";
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (NotesListView.SelectedItem is Note selectedNote)
            {
                string content = NoteTextBox.Text;
                if (!string.IsNullOrEmpty(content))
                {
                    UpdateNote(selectedNote.Id, content);
                    SaveButton.IsEnabled = false;
                    NoteTextBox.Clear();
                }
            }
        }

        private void NotesListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (NotesListView.SelectedItem is Note note)
            {
                NoteTextBox.Text = note.Content;
                SaveButton.IsEnabled = true;
            }
            else
            {
                SaveButton.IsEnabled = false;
            }
        }


        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (NotesListView.SelectedItem is Note selectedNote)
            {
                DeleteNote(selectedNote.Id);
            }
            else
            {
                StatusLabel.Text = "Seleccione una nota para eliminar.";
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadNotes();
        }
    }

    public class Note
    {
        public int Id { get; set; }
        public string Content { get; set; }
    }
}
