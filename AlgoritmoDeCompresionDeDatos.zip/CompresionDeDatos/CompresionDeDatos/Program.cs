﻿using System;
using Procedimientos;

Console.WriteLine("Ingrese su cadena");
string texto = Console.ReadLine();
Console.WriteLine(Bloque.Convertir(texto));