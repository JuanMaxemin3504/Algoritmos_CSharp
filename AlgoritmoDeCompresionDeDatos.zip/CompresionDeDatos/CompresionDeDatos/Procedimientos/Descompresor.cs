﻿using System;

namespace Procedimientos
{
    public class Descompresor
    {
        public static string Descomprimir(string Entrada)
        {
            string resultado = "";
            string[] Partes = Entrada.Split(' ');

            for (int i = 0; i < Partes.Length; i++)
            {
                string[] comprobacion = Partes[i].Split(',');
                int numero1 = int.Parse(comprobacion[0]);
                int numero2 = int.Parse(comprobacion[1]);

                char caracter = (char)numero1;
                string binario = Convert.ToString(numero2, 2).PadLeft(8, '0');
                string binario1 = binario.Substring(0, 3);
                string binario2 = binario.Substring(3);

                int posicion = 0;
                int FinalDato1 = 2, XDato = 1;
                for (double z = 0; z < 3; z++)
                {
                    if (binario1[FinalDato1] == '1')
                    {
                        posicion += XDato;
                    }
                    XDato *= 2;
                    FinalDato1--;
                }

                int repeticion = 0;
                int FinalDato2 = 4, XDato2 = 1;
                for (double z = 0; z < 5; z++)
                {
                    if (binario2[FinalDato2] == '1')
                    {
                        repeticion += XDato2;
                    }
                    XDato2 *= 2;
                    FinalDato2--;
                }

                if (repeticion > 0)
                {
                    int pos = resultado.Length - posicion;
                    for (int a = repeticion; a > 0; a--)
                    {
                        resultado += resultado[pos];
                        pos++;
                    }
                }

                resultado += caracter;
            }

            return resultado;
        }
    }
}
