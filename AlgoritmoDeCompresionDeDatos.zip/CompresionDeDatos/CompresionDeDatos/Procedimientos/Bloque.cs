﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Procedimientos
{
    public class Bloque
    {
        public static string Convertir(string Entrada)
        {
            bool Descompri = false, Compri = false;
            int longitud = Entrada.Length;

            if (Entrada.EndsWith(" "))
            {
                Entrada = Entrada.Substring(0, longitud - 1);
            }
            
            string[] Partes = Entrada.Split(' ');

            try
            {
                foreach (string partes in Partes)
                {
                    string[] comprobacion = partes.Split(',');
                    int numero1 = int.Parse(comprobacion[0]);
                    int numero2 = int.Parse(comprobacion[1]);
                }
                Descompri = true;
            }
            catch (IndexOutOfRangeException) 
            {
                Descompri = false;
            }
            catch (FormatException)
            {
                Descompri = false;
            }

            foreach (string partes in Partes)
            {
                if (Regex.IsMatch(partes, "^[a-zA-Z]+$"))
                {
                    Compri = true;
                }
            }

            if (Compri == true) { return Compresor.Comprimir(Entrada); }
            if (Descompri == true) { return Descompresor.Descomprimir(Entrada); }

            return Errores(1);
        }

        static string Errores(int error)
        {
            if (error == 1) { return "Formato ingresado incorrectamente"; }
            return "Error no encontrado";
        }
    }
}
