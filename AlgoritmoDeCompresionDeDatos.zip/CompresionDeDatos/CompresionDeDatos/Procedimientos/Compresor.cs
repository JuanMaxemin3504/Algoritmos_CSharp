﻿using System;
using System.Collections.Generic;

namespace Procedimientos
{
    public class Compresor
    {
        char character;
        int posicion;
        int repeticion;
        int primerbyte;
        int segundobyte;

        public static string Comprimir(string Entrada)
        {
            int longitud = Entrada.Length;
            List<Compresor> lista = new List<Compresor>();
            int pos = 0, repeticion, inicio, simbolo;
            bool repet;

            while (pos < longitud)
            {
                repet = false;
                simbolo = 0;
                repeticion = 0;
                inicio = pos;

                if (pos < 7)
                {
                    for (int i = 0; i < inicio; i++)
                    {
                        if (Entrada[i] == Entrada[pos])
                        {
                            repeticion++;
                            pos++;
                            repet = true;
                            simbolo = inicio - i;
                        }
                        else
                        {
                            if (repet == true)
                            {
                                simbolo--;
                                break;
                            }
                        }
                    }

                    if (repet == true)
                    {
                        lista.Add(new Compresor(Entrada[pos], simbolo + repeticion, repeticion));
                    }
                    else
                    {
                        lista.Add(new Compresor(Entrada[pos], 0, 0));
                    }
                }
                else
                {
                    for (int i = pos - 7; i < inicio; i++)
                    {
                        if (Entrada[i] == Entrada[pos])
                        {
                            repeticion++;
                            pos++;
                            repet = true;
                            simbolo = inicio - i;
                        }
                        else
                        {
                            if (repet == true)
                            {
                                simbolo--;
                                break;
                            }
                        }
                    }

                    if (repet == true)
                    {
                        lista.Add(new Compresor(Entrada[pos], simbolo + repeticion, repeticion));
                    }
                    else
                    {
                        lista.Add(new Compresor(Entrada[pos], 0, 0));
                    }
                }

                if (pos == longitud - 2)
                {
                    lista.Add(new Compresor(Entrada[pos + 1], 0, 0));
                    break;
                }

                pos++;
            }

            return DatosACadena(lista);
        }

        public static string DatosACadena(List<Compresor> lista)
        {
            string resultado = "";
            List<Compresor> lista2 = new List<Compresor>();

            Console.WriteLine("Contenido de la lista:");
            foreach (Compresor comp in lista)
            {
                int byte1 = comp.character;
                string parte1 = Convert.ToString(comp.posicion, 2);
                string parte2 = Convert.ToString(comp.repeticion, 2);

                parte1 = parte1.PadLeft(3, '0');
                parte2 = parte2.PadLeft(5, '0');

                string byte2S = parte1 + parte2;
                int Binario = 0;
                int FinalDato = 7, XDato = 1;

                for (double i = 0; i < 8; i++)
                {
                    if (byte2S[FinalDato] == '1')
                    {
                        Binario += XDato;
                    }
                    XDato *= 2;
                    FinalDato--;
                }

                lista2.Add(new Compresor(byte1, Binario));
            }

            foreach (Compresor comp2 in lista2)
            {
                resultado += $"{comp2.primerbyte},{comp2.segundobyte} ";
            }

            return resultado.Trim();
        }

        public Compresor(int primero, int segundo)
        {
            this.primerbyte = primero;
            this.segundobyte = segundo;
        }

        public Compresor(char character, int number1, int number2)
        {
            this.character = character;
            this.posicion = number1;
            this.repeticion = number2;
        }
    }
}
