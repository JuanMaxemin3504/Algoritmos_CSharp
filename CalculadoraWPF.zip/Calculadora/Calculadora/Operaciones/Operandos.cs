﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Calculadora.Operaciones
{
    internal class Operandos
    {
        public static string calcular(string entrada)
        {
            string resultado = "";
            string[] operadores = { "+", "-", "/", "*", "√", "√" };
            string[] elementos = entrada.Split(' ');
            if (elementos[elementos.Length - 1] == "")
            {
                Array.Resize(ref elementos, elementos.Length - 1);
            }
            if (elementos[elementos.Length - 1] == "." || elementos[elementos.Length - 1] == "0" || elementos.Length < 2)
                return entrada;
            
            foreach (string ele in operadores) {
                if (elementos[elementos.Length - 1] == ele)
                {
                    //poner alerta
                    return entrada;
                }
            }
            foreach (string ele in elementos)
            {
                if (double.TryParse(ele, out double numero))
                {
                    if (numero == 0)
                        return entrada;
                }
                else
                {
                    bool simbolo = false;
                    foreach (string ele2 in operadores)
                    {
                        if (ele2 == ele)
                        {
                            simbolo = true;
                        }
                    }
                    if (simbolo == false)
                        return entrada;
                }
            }
            List<string> arr = new List<string>(elementos);
            int longitud = arr.Count;
            for (int i = 5; i > 0; i -= 2)
            {
                for (int j = 0; j < longitud; j++)
                {
                    if (arr[j] == operadores[i] || arr[j] == operadores[i - 1])
                    {
                        string res = ".1";
                        if (arr[j] == "√")
                        {
                            res = raiz(arr[j + 1]);
                            arr[j + 1] = res;
                            arr.RemoveAt(j);
                            longitud = arr.Count;
                            j = 0;
                        }

                        if (arr[j] == "*")
                        {
                            res = multiplicacion(arr[j - 1], arr[j + 1]);
                            arr[j - 1] = res;
                            arr.RemoveAt(j + 1);
                            arr.RemoveAt(j);
                            longitud = arr.Count;
                            j = 0;
                        }
                        if (arr[j] == "/")
                        {
                            res = division(arr[j - 1], arr[j + 1]);
                            arr[j - 1] = res;
                            arr.RemoveAt(j + 1);
                            arr.RemoveAt(j);
                            longitud = arr.Count;
                            j = 0;
                        }
                        if (arr[j] == "+")
                        {
                            res = suma(arr[j - 1], arr[j + 1]);
                            arr[j - 1] = res;
                            arr.RemoveAt(j + 1);
                            arr.RemoveAt(j);
                            longitud = arr.Count;
                            j = 0;
                        }
                        if (arr[j] == "-")
                        {
                            res = resta(arr[j - 1], arr[j + 1]);
                            arr[j - 1] = res;
                            arr.RemoveAt(j + 1);
                            arr.RemoveAt(j);
                            longitud = arr.Count;
                            j = 0;
                        }
                    }
                }
                if (longitud == 1)
                    break;
            }
            foreach (string ele2 in arr)
            {
                resultado += ele2;
            }
            return resultado;
        }

        private static string suma(string entrada1, string entrada2) 
        {
            double num1 = double.Parse(entrada1);
            double num2 = double.Parse(entrada2);
            return (num1 + num2).ToString();
        }
        private static string resta(string entrada1, string entrada2)
        {
            double num1 = double.Parse(entrada1);
            double num2 = double.Parse(entrada2);
            return (num1 - num2).ToString();
        }
        private static string multiplicacion(string entrada1, string entrada2)
        {
            double num1 = double.Parse(entrada1);
            double num2 = double.Parse(entrada2);
            return (num1 * num2).ToString();
        }
        private static string division(string entrada1, string entrada2)
        {
            double num1 = double.Parse(entrada1);
            double num2 = double.Parse(entrada2);
            return (num1 / num2).ToString();
        }
        private static string raiz(string entrada1)
        {
            double num1 = double.Parse(entrada1);
            return Math.Sqrt(num1).ToString();
        }
    }
}
