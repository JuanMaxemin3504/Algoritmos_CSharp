﻿using Calculadora.Operaciones;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Calculadora
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnNumero(object sender, RoutedEventArgs e)
        {
            var boton = (System.Windows.Controls.Button)sender;
            string numero = boton.Content.ToString();
            if (Texto.Text == "0")
                Texto.Text = numero;
            else
            {
                char ultimo = Texto.Text[Texto.Text.Length - 1];
                if (ultimo == '+' || ultimo == '-' || ultimo == '*' || ultimo == '/' || ultimo == '√')
                    Texto.Text += " ";
                Texto.Text += numero;
            }                
        }

        private void BtnResultado(object sender, RoutedEventArgs e)
        {
            Texto.Text = Operandos.calcular(Texto.Text);
        }

        private void BtnOperador(object sender, RoutedEventArgs e)
        {
            var boton = (System.Windows.Controls.Button)sender;
            string operador = boton.Content.ToString();
            char ultimo = Texto.Text[Texto.Text.Length - 1];
            char antepenultimo = ' ';
            if (Texto.Text.Length > 1)
                antepenultimo = Texto.Text[Texto.Text.Length - 2];

            if (ultimo == '+' || ultimo == '-' || ultimo == '/' || ultimo == '*' || ultimo == '√')
                Texto.Text += " ";
            else
            {
                if (Texto.Text != "0" && ultimo != ' ' && ultimo != '+'
                && ultimo != '-' && ultimo != '/' && ultimo != '*' && ultimo != '√' && operador != "√")
                    Texto.Text += " " + operador + " ";
                else
                {
                    if (Texto.Text == "0")
                    {
                        Texto.Text = operador + " ";
                    }
                    else
                    {
                        if (operador == "√")
                        {
                            bool numerosB = false, operadoresB = false;
                            char[] operadores = { '+', '-', '*', '/', '√' };
                            char[] numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
                            for(int i = Texto.Text.Length - 1; i >= 0; i--)
                            {
                                char c = Texto.Text[i];
                                foreach(char c2 in operadores) { 
                                    if(c == c2)
                                    {
                                        operadoresB = true;
                                        break;
                                    }
                                }
                                foreach (char c3 in numeros)
                                {
                                    if (c == c3)
                                    {
                                        numerosB = true;
                                        break;
                                    }
                                }
                                if (operadoresB == true || numerosB == true)
                                {
                                    if (c != '√')
                                    {
                                        if (numerosB)
                                            Texto.Text += " * " + operador + " ";
                                        if (operadoresB)
                                            Texto.Text += " " + operador + " ";
                                    }
                                    break;                                
                                }
                            }
                        }
                    }
                }
            }            
        }

        private void BtnLimpiar(object sender, RoutedEventArgs e)
        {
            
        }

        private void BtnLimpiarTodo(object sender, RoutedEventArgs e)
        {
            Texto.Text = "0";
        }

        private void BtnEliminar(object sender, RoutedEventArgs e)
        {
                if (Texto.Text != "0" && Texto.Text.Length > 1)
                    Texto.Text = Texto.Text.Substring(0, Texto.Text.Length - 1);
                else
                    Texto.Text = "0";          
        }

        private void BtnPunto(object sender, RoutedEventArgs e)
        {
            bool PuntoExistente = false;
            for (int i = Texto.Text.Length - 1; i > 0; i--) { 
                if(Texto.Text[i] == '.')
                {
                    PuntoExistente = true;
                    break;
                }
                if (Texto.Text[i] == ' ')
                    break;
            }
            if(PuntoExistente == false)
            {
                char ultimo = Texto.Text[Texto.Text.Length - 1];
                if (ultimo == '+' || ultimo == '-' || ultimo == '*' || ultimo == '/' || ultimo == '√')
                    Texto.Text += " ";
                Texto.Text += ".";
            }
        }
    }
}