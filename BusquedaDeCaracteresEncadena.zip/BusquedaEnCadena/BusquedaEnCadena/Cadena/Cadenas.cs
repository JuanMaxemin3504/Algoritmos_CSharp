﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusquedaEnCadena.Cadena
{
    internal class Cadenas
    {
        public static string ObtenerCadenas(string cadena1, string cadena2)
        {
            if (cadena1 == "") { return CodigosDeError(1); }
            if (cadena2 == "") { return CodigosDeError(2); }
            // Convertir los caracteres de la cadena 2 en un arreglo de char para luego 
            // usarlos como llaves para el diccionario
            char[] caracteresBuscados = cadena2.ToCharArray();
            // Eliminar caracteres repetidos
            HashSet<char> caracteresUnicos = new HashSet<char>(caracteresBuscados);
            char[] resultado = new char[caracteresUnicos.Count];
            caracteresUnicos.CopyTo(resultado);
            caracteresBuscados = resultado;
            // Crear el diccionario usando de llaves un char y guardando las pocisiones en una lista
            Dictionary<char, List<int>> posiciones = new Dictionary<char, List<int>>();
            // Usando los caracteres de la cadena 2 para crear las llaves del diccionario
            // para luego ingresar las pocisiones incluso si se repiten no se creara una nueva llave
            foreach (char caracter in caracteresBuscados)
            {
                posiciones[caracter] = new List<int>();
            }

            // Comprobar que todos los caracteres de la segunda cadena se encuentran en la primera cadena
            for (int i = 0; i < cadena2.Length; i++)
            {
                bool Encontrado = false;
                for(int x = 0; x < cadena1.Length; x++)
                {
                    if (cadena1.Contains(cadena2[i]))
                    {
                        Encontrado = true;
                        break;
                    }
                }
                if (Encontrado == false) { return CodigosDeError(0); }
            }
            // Usando las llaves del diccionrio guardamos la posicion en la lista dentro del diccionario
            for (int z = 0; z < cadena1.Length; z++)
            {
                char caracterActual = cadena1[z];
                if (posiciones.ContainsKey(caracterActual))
                {
                    posiciones[caracterActual].Add(z);
                }
            }

            List<List<int>> combinaciones = new List<List<int>>();
            GenerarCombinaciones(posiciones, caracteresBuscados, 0, new List<int>(), combinaciones);
            int distancia = 0;
            foreach (var combinacion in combinaciones)
            {
                combinacion.Sort();
                int Primero = combinacion.First();
                int Ultimo = combinacion.Last();
                if(distancia == 0) { distancia = Ultimo - Primero; }
                else { if(distancia > Ultimo - Primero) distancia = Ultimo - Primero; }
                //Console.WriteLine($"[{string.Join(", ", combinacion)}]");
            }
            int contador = 0;
            foreach (var combinacion in combinaciones)
            {
                string CadenaCopia = cadena1;
                int Primero = combinacion.First();
                int Ultimo = combinacion.Last();
                if( distancia == Ultimo - Primero) 
                {
                    contador++;
                    string subcadena1 = CadenaCopia.Substring(Primero, distancia+1);
                    Console.WriteLine(contador + ": " + subcadena1);
                    
                }
            }
            return contador + " cadenas igual de cerca";
        }

        static void GenerarCombinaciones(Dictionary<char, List<int>> posiciones, char[] caracteresBuscados, int indice, List<int> combinacionActual, List<List<int>> combinaciones)
        {
            // Caso base: si hemos seleccionado una posición para cada carácter buscado
            if (indice == caracteresBuscados.Length)
            {
                combinaciones.Add(new List<int>(combinacionActual)); // Agregar copia de la combinación actual a las combinaciones
                return;
            }

            // Obtener el carácter actual y sus posiciones
            char caracterActual = caracteresBuscados[indice];
            List<int> posicionesActuales = posiciones[caracterActual];

            // Recorrer todas las posiciones posibles del carácter actual
            foreach (int posicion in posicionesActuales)
            {
                combinacionActual.Add(posicion);  // Agregar posición actual a la combinación
                GenerarCombinaciones(posiciones, caracteresBuscados, indice + 1, combinacionActual, combinaciones);  // Llamada recursiva
                combinacionActual.RemoveAt(combinacionActual.Count - 1);  // Quitar la última posición agregada para probar la siguiente
            }
        }

        static string CodigosDeError(int error)
        {
            if (error == 0) { return "La primera cadena no contiene uno o mas de los caracteres ingresados en la segunda cadena"; }

            if (error == 1) { return "Primera cadena vacia"; }

            if (error == 2) { return "Segunda cadena vacia"; }

            return "Error no econtrado";
        }
    }
}
