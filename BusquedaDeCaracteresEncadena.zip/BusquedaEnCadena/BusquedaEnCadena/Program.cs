﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusquedaEnCadena.Cadena;

for(int i = 0; i < 10; i++)
{
    Console.WriteLine("Ingrese su primera cadena: ");
    string cadena1 = Console.ReadLine();
    Console.WriteLine("Ingrese su segunda cadena: ");
    string cadena2 = Console.ReadLine();
    Console.WriteLine(Cadenas.ObtenerCadenas(cadena1, cadena2));
}




