﻿using Fechas.Fechas;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

string fecha = Console.ReadLine();
Console.WriteLine(Fecha.ConvertirFecha(fecha));


