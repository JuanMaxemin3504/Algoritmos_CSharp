﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Fechas.Fechas
{
    internal class Fecha
    {
        public static string ConvertirFecha(string fecha)
        {
            int total = Regex.Matches(fecha, "/").Count;
            if(total > 0)
            {
                if(total < 2 || total > 2) { return "Formato de fecha introducido incorrectamente"; }
                if (fecha.EndsWith("/")) { return "Fecha introducida incorrectamente ya que termina con /"; }
                if (fecha.StartsWith("/")) { return "Fecha introducida incorrectamente ya que termina con /"; }

                string[] partes = fecha.Split("/");
                int dia, mes, año;
                try { dia = int.Parse(partes[0]); }
                catch (System.FormatException) { return "Dia ingresado incorrectamente"; }

                try { mes = int.Parse(partes[1]); }
                catch (System.FormatException) { return "Mes ingresado incorrectamente"; }

                try { año = int.Parse(partes[2]); }
                catch (System.FormatException) { return "Año ingresado incorrectamente"; }
                string res = comprovacionFechaValida(fecha);
                if(res != "") { return res; }
                return fechaANumeros(fecha);

            }
            else
            {
                try { uint fechaComprobacion = uint.Parse(fecha); }
                catch (System.FormatException) { return "Se han ingresado simbolo o letras"; }

                try { uint fechaOverflow = uint.Parse(fecha); }
                catch (System.OverflowException) { return "Dato mayor a 32 bits, con signo negativo o con signo positivo"; }

                uint fechaNumeros = uint.Parse(fecha);
                string resultado = numerosAFechas(fechaNumeros);
                string res = comprovacionFechaValida(resultado);
                if (res != "") { return res; }
                return resultado;
            }
        }

        private static string numerosAFechas(uint fecha)
        {
            string Binario = Convert.ToString(fecha, toBase: 2);
            int longitud = Binario.Length;
            for (int i = longitud; i < 32; i++)
            {
                Binario = "0" + Binario;
            }
            string año = Binario.Substring(0,23);
            Binario = Binario.Remove(0,23);
            string mes = Binario.Substring(0, 4);
            Binario = Binario.Remove(0,4);
            string dia = Binario.Substring(0, 5);

            double AñoNumero = 0;
            int FinalAño = 22, XAño = 1;
            for (double i = 0; i < 23; i++)
            {
                if (año[FinalAño] == '1')
                {
                    AñoNumero = AñoNumero + XAño;
                }
                XAño = XAño * 2;
                FinalAño--;
            }

            double MesNumero = 0;
            int FinalMes = 3, XMes = 1;
            for (double i = 0; i < 4; i++)
            {
                if (mes[FinalMes] == '1')
                {
                    MesNumero = MesNumero + XMes;
                }
                XMes = XMes * 2;
                FinalMes--;
            }

            double DiaNumero = 0;
            int FinalDia = 4, XDia = 1;
            for (double i = 0; i < 5; i++)
            {
                if (dia[FinalDia] == '1')
                {
                    DiaNumero = DiaNumero + XDia;
                }
                XDia = XDia * 2;
                FinalDia--;
            }

            return DiaNumero + "/" + MesNumero + "/" + AñoNumero;
        }

        private static string comprovacionFechaValida(string fecha)
        {
            string[] partes = fecha.Split('/');
            int Dia = int.Parse(partes[0]);
            int Mes = int.Parse(partes[1]);
            int Año = int.Parse(partes[2]);

            if (Dia > 31 || Dia < 1) { return "Dia introducido invalido ya que es mayor a 31 o menor 1"; }

            if (Dia > 28 && Mes == 2)
            {
                if(Año % 4 != 0)
                { return "febreno no tiene mas de 28 dias y no es bisiestos"; }
            } 
            

            if (Dia == 31 && (Mes  == 1 || Mes == 3 || Mes == 5 
                || Mes == 7 || Mes == 8 || Mes == 10 || Mes == 12)) 
            { return "Dia introducido invalido ya que el mes no tiene 31 dias"; }

            if (Mes > 12 || Mes < 1) { return "Mes el mes intruducido no existe"; }

            if (Año < 1) { return "Año menor a 1"; }
            return "";
        }

        private static string fechaANumeros(string fecha)
        {
            string[] partes = fecha.Split('/');
            int Dia = int.Parse(partes[0]);
            int Mes = int.Parse(partes[1]);
            int Año = int.Parse(partes[2]);

            string BinarioDia = Convert.ToString(Dia, toBase: 2);
            string BinarioMes = Convert.ToString(Mes, toBase: 2);
            string BinarioAño = Convert.ToString(Año, toBase: 2);
            for (int i = BinarioDia.Length; i < 5; i++)
            {
                BinarioDia = "0" + BinarioDia;
            }
            for (int i = BinarioMes.Length; i < 4; i++)
            {
                BinarioMes = "0" + BinarioMes;
            }
            for (int i = BinarioAño.Length; i < 23; i++)
            {
                BinarioAño = "0" + BinarioAño;
            }
            string Binario = BinarioAño + BinarioMes + BinarioDia;

            int FechaNumero = 0, XFecha = 1;
            int FinalFecha = Binario.Length - 1;
            int Ciclo = Binario.Length;
            for (int i = 0; i < Ciclo; i++)
            {
                if (Binario[FinalFecha] == '1')
                {
                    FechaNumero = FechaNumero + XFecha;
                }
                XFecha = XFecha * 2;
                FinalFecha--;
            }
            return FechaNumero.ToString();
        }
    }
}
