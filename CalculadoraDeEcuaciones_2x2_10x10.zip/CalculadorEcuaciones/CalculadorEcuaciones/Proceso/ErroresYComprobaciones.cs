﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CalculadorEcuaciones.Proceso
{
    internal class ErroresYComprobaciones
    {
        public static int ComprobarEcuacion(string ecuacion)
        {
            if (ecuacion == "") { return 2; }
            if (ecuacion.Contains('x')) { return 0; }
            if (ecuacion.Contains('X')) { return 0; }
            else {  return 3; }
        }

        public static int ComprobacionTolerancia(string Tolerancia)
        {
            double tole;
            try
            {
                tole = double.Parse(Tolerancia);
            }
            catch (System.FormatException)
            {
                return 5;
            }
            if(tole < 0) { return 6; }
            if(tole > 9) { return 7; }
            if(tole > 1)
            {
                try
                {
                    int toleint = int.Parse(Tolerancia);
                }
                catch(System.FormatException)
                {
                    return 10;
                }
            }
            return 0;
        }

        public static int ComprobacionInicio(string Inicio)
        {
            try
            {
                double tole = double.Parse(Inicio);
            }
            catch (System.FormatException)
            {
                return 4;
            }
            return 0;
        }

        public static int ComprobacionProceso(string Proceso)
        {
            if (Proceso.Length > 1) { return 9; }
            if (Proceso == "s" || Proceso == "S" || Proceso == "n" || Proceso == "N")
            {
                return 0;
            }
            return 8;
        }

        public static string Errores(int error)
        {
            //if (error == ) { return ""; }
            if (error == 1) { return "El punto inicial da a una solucion indefinida o la tolerancia no es suficiente"; }
            if (error == 2) { return "La ecuacion esta vacia"; }
            if (error == 3) { return "La ecuacion no contiene X"; }
            if (error == 4) { return "El punto de inicio contiene simbolos o letras"; }
            if (error == 5) { return "Tolerancia introducida contienen simbolos, letras o esta vacio"; }
            if (error == 6) { return "La Tolerancia es menor a 0"; }
            if (error == 7) { return "La tolerancia es mayor a 9 decimales"; }
            if (error == 8) { return "No se ha introducido un 'S' o 'N' en ver proceso"; }
            if (error == 9) { return "Proceso no introducido correctamente"; }
            if (error == 10) { return "Tolerancia introducida incorrectamente introdusca un numero enteros o puros decimales"; }

            return "Error no entontrado";
        }
    }
}
