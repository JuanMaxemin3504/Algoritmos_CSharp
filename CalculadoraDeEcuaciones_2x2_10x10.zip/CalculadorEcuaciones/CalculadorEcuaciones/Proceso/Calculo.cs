﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CalculadorEcuaciones.Proceso
{
    internal class Calculo
    {
        public static string Calcular(string Ecuacion, string Inicio, string Tolerancia, string Iteraciones)
        {
            int error = ((ErroresYComprobaciones.ComprobarEcuacion(Ecuacion) != 0) ? ErroresYComprobaciones.ComprobarEcuacion(Ecuacion)
                : (ErroresYComprobaciones.ComprobacionTolerancia(Tolerancia) != 0) ? ErroresYComprobaciones.ComprobacionTolerancia(Tolerancia)
                : (ErroresYComprobaciones.ComprobacionInicio(Inicio) != 0) ? ErroresYComprobaciones.ComprobacionInicio(Inicio)
                : (ErroresYComprobaciones.ComprobacionProceso(Iteraciones) != 0) ? ErroresYComprobaciones.ComprobacionProceso(Iteraciones)
                : 0);
            if(error != 0) { return ErroresYComprobaciones.Errores(error); }
            Ecuacion = Ecuacion.Replace("X", "x");
            double PuntoInicial;
                if(Inicio == "0")
            {
                PuntoInicial = 0;
            }
            else
            {
                PuntoInicial = double.Parse(Inicio);
            }
            
            int Decimales = 0;
            double Temporal = double.Parse(Tolerancia);
            if(Temporal < 1)
            {
                while(Temporal < 1)
                {
                    Decimales++;
                    Temporal = Temporal * 10;
                }
            }
            else
            {
                Decimales = int.Parse(Tolerancia);
            }
            string Fx = Derivada.Derivar(Ecuacion);
            List<List<double>> listaDeProcesos = new List<List<double>>();
            double A = PuntoInicial;
            double B = double.Parse(Proceso(Ecuacion, PuntoInicial));
            double C = double.Parse(Proceso(Fx, PuntoInicial));
            double D = A - (B / C);
            listaDeProcesos.Add(new List<double> { A, B, C, D });
            if (double.IsInfinity(D))
            {
                D = 0.000000001;
            }
            PuntoInicial = D;
            int Bucle = 0;
            double PuntoDeParo = 1;
            if (Iteraciones == "s" || Iteraciones == "S")
            {
                Console.WriteLine($"{"Iteracion",-9} {"|"} {"Dato",-25} {"|"} {Ecuacion,-25} {"|"} {Fx,-25} {"|"} {"Siguiente Dato",-25}");
            }
            while (PuntoDeParo != 0)
            {
                A = D;
                B = double.Parse(Proceso(Ecuacion, PuntoInicial));
                C = double.Parse(Proceso(Fx, PuntoInicial));
                D = A - (B / C);
                if (double.IsInfinity(D))
                {
                    D = 0.000000001;
                }
                listaDeProcesos.Add(new List<double> { A, B, C, D });
                PuntoInicial = D;
                PuntoDeParo = B;
                PuntoDeParo = Math.Round(PuntoDeParo, Decimales);
                if (Iteraciones == "s" || Iteraciones == "S")
                {
                    Console.WriteLine($"{Bucle,-9} {"|"} {A,-25} {"|"} {B,-25} {"|"} {C,-25} {"|"} {D,-25}");
                }
                if (Bucle == 1000) return ErroresYComprobaciones.Errores(1);
                Bucle++;
            }
            A = D;
            B = double.Parse(Proceso(Ecuacion, PuntoInicial));
            C = double.Parse(Proceso(Fx, PuntoInicial));
            D = A - (B / C);
            if (Iteraciones == "s" || Iteraciones == "S")
            {
                Console.WriteLine($"{Bucle,-9} {"|"} {A,-25} {"|"} {B,-25} {"|"} {C,-25} {"|"} {D,-25}");
            }
            listaDeProcesos.Add(new List<double> { A, B, C, D });

            return "El valor mas cercano al punto inicial es: " + A;
         }

        public static string Proceso(string Ecuacion, double PuntoInicial)
        {
            string patron = @"([+-]?\s*\d*)x(\^?(\d+))?|([+-]?\s*\d+)";
            Regex regex = new Regex(patron);
            MatchCollection terminos = regex.Matches(Ecuacion);

            double Resultado = 0;

            foreach (Match termino in terminos)
            {
                string coeficienteStr = termino.Groups[1].Value.Replace(" ", "");
                string exponenteStr = termino.Groups[3].Value;

                int coeficiente = (coeficienteStr == "" || coeficienteStr == "+") ? 1 :
                                  (coeficienteStr == "-") ? -1 : int.Parse(coeficienteStr);
                double exponente = (exponenteStr == "") ? 1 : int.Parse(exponenteStr);
                if (coeficiente > 1 && exponente == 1) { Resultado = Resultado + coeficiente; }
                if(termino.Groups[1].Value != "" || termino.Groups[3].Value != "" || termino.Groups[0].Value == "x")
                {

                    Resultado = Resultado + (Math.Pow(PuntoInicial, exponente) * coeficiente);
                }
                else
                {
                    int constante = int.Parse(termino.Groups[0].Value.Replace(" ", ""));
                    Resultado = Resultado + constante;
                }               
            }
            return Resultado.ToString();
        }
    }
}


