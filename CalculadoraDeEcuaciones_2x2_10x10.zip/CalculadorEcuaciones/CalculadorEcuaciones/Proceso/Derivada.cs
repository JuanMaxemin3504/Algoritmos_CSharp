﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CalculadorEcuaciones.Proceso
{
    internal class Derivada
    {
        public static string Derivar(string ecuacion)
        {
            string patron = @"([+-]?\s*\d*)x(\^?(\d+))?";
            Regex regex = new Regex(patron);
            MatchCollection terminos = regex.Matches(ecuacion);

            string derivada = "";

            foreach (Match termino in terminos)
            {
                string coeficienteStr = termino.Groups[1].Value.Replace(" ", "");
                string exponenteStr = termino.Groups[3].Value;

                int coeficiente = (coeficienteStr == "" || coeficienteStr == "+") ? 1 :
                                  (coeficienteStr == "-") ? -1 : int.Parse(coeficienteStr);

                int exponente = (exponenteStr == "") ? 1 : int.Parse(exponenteStr);

                if (exponente == 1)
                {
                    derivada += $"{(coeficiente > 0 && derivada != "" ? "+" : "")}{coeficiente}";
                }
                else
                {
                    int nuevoCoeficiente = coeficiente * exponente;
                    int nuevoExponente = exponente - 1;

                    if (nuevoExponente == 1)
                    {
                        derivada += $"{(nuevoCoeficiente > 0 && derivada != "" ? "+" : "")}{nuevoCoeficiente}x";
                    }
                    else
                    {
                        derivada += $"{(nuevoCoeficiente > 0 && derivada != "" ? "+" : "")}{nuevoCoeficiente}x^{nuevoExponente}";
                    }
                }
            }

            return derivada;
        }
    }
}
