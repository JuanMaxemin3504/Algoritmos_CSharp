﻿
using CalculadorEcuaciones.Proceso;
using System.Text.RegularExpressions;
for(int i = 0; i < 10; i++)
{
Console.WriteLine("Ingresa la ecuacion");
    string Ecuacion = Console.ReadLine();
Console.WriteLine("Ingrese el punto de inicio");
    string PuntoDeInicio = Console.ReadLine();
Console.WriteLine("Ingrese la tolerancia.");
    string Tolerancia = Console.ReadLine();
Console.WriteLine("Quiere ver el proceso? S/N");
    string Proceso = Console.ReadLine();
Console.WriteLine(Calculo.Calcular(Ecuacion, PuntoDeInicio, Tolerancia, Proceso));
}

//x^7 - 2x^3 + 1